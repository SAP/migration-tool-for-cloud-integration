import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.esb.datastore.DataStore
import com.sap.esb.datastore.Data
import org.osgi.framework.*
import groovy.xml.*
import java.time.*

Message processData(Message message) {
    def camelCtx = message.exchange.getContext()
	DataStore dataStore = (DataStore)camelCtx.getRegistry().lookupByName(DataStore.class.getName())
	
	def payload = """<root></root>""" //this line will be updated by the migration tool
	
    def root = new XmlSlurper().parseText(payload)
    root.store.each { s ->
        s.entries.entry.each { e ->
            Map<String, Object> headers = [:]
            e.headers.header.each { h ->
                headers.put(h.key.text(), h.value.text())
            }

            LocalDateTime now = LocalDateTime.now()
            Long alert = (Long)(Duration.between(now, LocalDateTime.parse(e.alert.text())).toSeconds() * 1000)
            alert = Math.max(alert, 1)
            Long expire = (Long)(Duration.between(now, LocalDateTime.parse(e.expire.text())).toSeconds() * 1000)
            expire = Math.max(expire, 1)

            def iflow = s.flow.text()
            iflow = iflow.length() == 0 ? null : iflow
            
            //params => (DatastoreName, ContextName, EntryId, Body, Headers, MessageId, Version)
            Data dsData = new Data(s.name.text(), iflow, e.id.text(), e.body.text().getBytes("UTF-8"), headers, e.messageid.text(), 0)
            //params => (DataInstance, overwriteEntry, encrypt, alertPeriodInMs, expirePeriodInMs)
            dataStore.put(dsData, true, true, alert, expire)
        }
    }
    return message
}